package com.example.sizingmanagement.Stocks;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.sizingmanagement.Stocks.StockAPI.StockAPIController;
import com.example.sizingmanagement.Universal.CheckFieldIsEmpty;
import com.example.sizingmanagement.databinding.ActivityInsertStockBinding;

import java.util.ArrayList;
import java.util.Calendar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InsertStock extends AppCompatActivity {

    ActivityInsertStockBinding binding;
    String clientCode, DoNo, count, No_of_bags, weightPerBag, finalDate, finalTime, userName, jwt, HSNCode;
    int day, month, myYear, mm, hh, shift;
    Calendar calendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityInsertStockBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                clientCode = binding.edClientCode.getText().toString();
                DoNo = binding.edDoNo.getText().toString();
                count = binding.edCount.getText().toString();
                No_of_bags = binding.edNoOfBags.getText().toString();
                weightPerBag = binding.edWeight.getText().toString();
                HSNCode = binding.edHSNCode.getText().toString();
                HSNCode = binding.edHSNCode.getText().toString();
                ArrayList<String> list = new ArrayList<>();

                list.add(clientCode);
                list.add(DoNo);
                list.add(count);
                list.add(HSNCode);
                list.add(No_of_bags);
                list.add(weightPerBag);
                list.add(finalDate);
                list.add(finalTime);
                list.add(HSNCode);

                CheckFieldIsEmpty obj = new CheckFieldIsEmpty();
                if (obj.checkIsEmpty(list)) {

                    Toast.makeText(InsertStock.this, "All Fields are Mandatory", Toast.LENGTH_SHORT).show();
                } else {

                    insertStock();
                }

            }
        });

        // take date and time
        binding.btnDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getDate();
            }
        });

        binding.btnTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getTime();
            }
        });
    }

    // method to insertStock
    private void insertStock() {

        SharedPreferences preferences = getSharedPreferences("jwt_userName", MODE_PRIVATE);
        jwt = preferences.getString("jwt", null);

        if (jwt == null)
            Toast.makeText(this, "Something went wrong, Logout then logIn again ", Toast.LENGTH_SHORT).show();
        else {

            StockModel model = new StockModel(jwt, clientCode, DoNo, count, No_of_bags, weightPerBag, finalDate, finalTime, HSNCode);

            Call<Void> call = StockAPIController.getInstance().getAPI().insertStock(model);

            // TODO: show progress dialogue

            call.enqueue(new Callback<Void>() {
                @Override
                public void onResponse(Call<Void> call, Response<Void> response) {

                    if (response.code() == 500)
                        Toast.makeText(InsertStock.this, "Server Error, Try after sometime", Toast.LENGTH_SHORT).show();

                    else if (response.code() == 404)
                        Toast.makeText(InsertStock.this, "", Toast.LENGTH_SHORT).show();

                    else if (response.code() == 201) {

                        Toast.makeText(InsertStock.this, "Inserted Successfully", Toast.LENGTH_SHORT).show();
                        setEmptyText();
                    }
                }

                @Override
                public void onFailure(Call<Void> call, Throwable t) {

                    Toast.makeText(InsertStock.this, t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void setEmptyText() {

        binding.edClientCode.setText("");
        binding.edDoNo.setText("");
        binding.edNoOfBags.setText("");
        binding.edWeight.setText("");
        binding.edCount.setText("");
        binding.edDate.setText("");
        binding.edTime.setText("");
        binding.edHSNCode.setText("");
    }

    // method to get date
    private void getDate() {

        // current date
        day = calendar.get(Calendar.DAY_OF_MONTH);
        month = calendar.get(Calendar.MONTH);
        myYear = calendar.get(Calendar.YEAR);

        // dialogue to get date from user
        DatePickerDialog dialog = new DatePickerDialog(
                InsertStock.this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        day = dayOfMonth;
                        month = monthOfYear + 1;
                        myYear = year;

                        finalDate = day + "/" + month + "/" + myYear;
                        binding.edDate.setText(finalDate);
                    }
                }, myYear, month, day);

        dialog.show();
    }

    // method to get time
    public void getTime() {

        hh = calendar.get(Calendar.HOUR);
        mm = calendar.get(Calendar.MINUTE);
        shift = calendar.get(Calendar.AM_PM);

        TimePickerDialog dialog = new TimePickerDialog(InsertStock.this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                hh = hourOfDay;
                mm = minute;
                finalTime = hh + "-" + mm + " " + shift;
                binding.edTime.setText(finalTime);
            }
        }, hh, mm, false);

        dialog.show();
    }

}