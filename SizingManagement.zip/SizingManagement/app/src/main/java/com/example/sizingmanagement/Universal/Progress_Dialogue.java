package com.example.sizingmanagement.Universal;

public class Progress_Dialogue {
}
