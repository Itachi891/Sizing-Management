package com.example.sizingmanagement.Splash;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.sizingmanagement.DashBoard;
import com.example.sizingmanagement.R;
import com.example.sizingmanagement.databinding.ActivitySplashScreenBinding;

public class SplashScreen extends AppCompatActivity {

    ActivitySplashScreenBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySplashScreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                // use shared preferences to store check the user is logged in or not
                SharedPreferences preferences = getSharedPreferences("jwt_userName", MODE_PRIVATE);
                boolean flag = preferences.getBoolean("flag", false);
                if(flag) {

                startActivity(new Intent(SplashScreen.this, DashBoard.class));
                finish();
                }
            }
        }, 500);

        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();

        transaction.add(R.id.frag, new LogInFragment());
        transaction.commit();
    }
}