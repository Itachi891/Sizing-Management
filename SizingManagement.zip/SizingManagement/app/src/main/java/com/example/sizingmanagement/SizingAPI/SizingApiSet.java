package com.example.sizingmanagement.SizingAPI;

import com.example.sizingmanagement.SizingProfile.SizingModel;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.PUT;

public interface SizingApiSet {

    // logIn

    @Headers("Content-Type: application/json")
    @POST("/logIn")
    Call<String> logIn(@Body SizingModel model);

    // Edit profile
    @Headers("Content-Type: application/json")
    @PUT("/editProfile")
    Call<Void> editSizingProfile(@Body SizingModel model);

    // View profile
    @Headers("Content-Type: application/json")
    @FormUrlEncoded()
    @POST("/viewProfile")
    Call<SizingModel> viewSizingProfile(
            @Field("jwt") String jwt);
}
