package com.example.sizingmanagement.Clients.DisplayClients;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.sizingmanagement.Clients.ClientAPI.ClientAPIController;
import com.example.sizingmanagement.Stocks.AdapterDisplayStock;
import com.example.sizingmanagement.Stocks.DisplayStock;
import com.example.sizingmanagement.databinding.ActivityDisplayClientsBinding;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DisplayClients extends AppCompatActivity {

    ActivityDisplayClientsBinding binding;
    String clientCode, userName, jwt;
    ArrayList<ClientsModel> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDisplayClientsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                clientCode = binding.etDisClientCode.getText().toString().toLowerCase();
                if (clientCode.isEmpty())
                    Toast.makeText(DisplayClients.this, "Enter Client Name", Toast.LENGTH_SHORT).show();
                else {

                    binding.disRecycView.setLayoutManager(new LinearLayoutManager(DisplayClients.this));

                    SharedPreferences preferences = getSharedPreferences("jwt_userName", MODE_PRIVATE);
                    userName = preferences.getString("userName", null);
                    jwt = preferences.getString("jwt", null);

                    if (userName != null && jwt != null)
                        Toast.makeText(DisplayClients.this, "Something went wrong, Log In again then try", Toast.LENGTH_SHORT).show();
                    else {

                        displayClient();

                        DisplayClientsAdapter adapter = new DisplayClientsAdapter(DisplayClients.this, list);
                        binding.disRecycView.setAdapter(adapter);
                    }
                }
            }
        });
    }

    private void displayClient() {

        Call<ArrayList<ClientsModel>> call = ClientAPIController.getInstance().getAPI().displayClient(clientCode, jwt);

        call.enqueue(new Callback<ArrayList<ClientsModel>>() {
            @Override
            public void onResponse(Call<ArrayList<ClientsModel>> call, Response<ArrayList<ClientsModel>> response) {


                if (response.code() == 500)
                    Toast.makeText(DisplayClients.this, "Server Error", Toast.LENGTH_SHORT).show();

                else if (response.code() == 404)
                    Toast.makeText(DisplayClients.this, "Client not found", Toast.LENGTH_SHORT).show();
                else {

                    list = response.body();
                }
            }

            @Override
            public void onFailure(Call<ArrayList<ClientsModel>> call, Throwable t) {

                Toast.makeText(DisplayClients.this, "Something went wrong, Try after some times", Toast.LENGTH_SHORT).show();
            }
        });

    }
}