package com.example.sizingmanagement.Stocks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.sizingmanagement.databinding.ActivityStockDashBoardBinding;

public class StockDashBoard extends AppCompatActivity {

    ActivityStockDashBoardBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityStockDashBoardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // insert stock
        binding.insertStock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(StockDashBoard.this, InsertStock.class));
            }
        });

        // display stock
        binding.displayStock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(StockDashBoard.this, DisplayStock.class));
            }
        });

        binding.returnStock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(StockDashBoard.this, ReturnStock.class));
            }
        });
        
        binding.comingSoon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(StockDashBoard.this, "Coming Soon", Toast.LENGTH_SHORT).show();
            }
        });
    }
}