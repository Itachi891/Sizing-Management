package com.example.sizingmanagement.Stocks;

public class StockModel {

    public StockModel() {
    }

    String jwt, clientCode, DoNo, count, no_of_bags, weight_per_bag, stockDate, stockTime, HSNCode;

    public StockModel(String jwt, String clientCode, String doNo, String count, String no_of_bags, String weight_per_bag, String stockDate, String stockTime, String HSNCode) {
        this.jwt = jwt;
        this.clientCode = clientCode;
        DoNo = doNo;
        this.count = count;
        this.no_of_bags = no_of_bags;
        this.weight_per_bag = weight_per_bag;
        this.stockDate = stockDate;
        this.stockTime = stockTime;
        this.HSNCode = HSNCode;
    }

    public StockModel(String clientName, String doNo, String count, String no_of_bags, String weight_per_bag, String stockDate, String stockTime, String HSNCode) {
        this.clientCode = clientName;
        DoNo = doNo;
        this.count = count;
        this.no_of_bags = no_of_bags;
        this.weight_per_bag = weight_per_bag;
        this.stockDate = stockDate;
        this.stockTime = stockTime;
        this.HSNCode = HSNCode;
    }

    public String getHSNCode() {
        return HSNCode;
    }

    public void setHSNCode(String HSNCode) {
        this.HSNCode = HSNCode;
    }

    public String getClientName() {
        return clientCode;
    }

    public void setClientName(String clientName) {
        this.clientCode = clientName;
    }

    public String getDoNo() {
        return DoNo;
    }

    public void setDoNo(String doNo) {
        DoNo = doNo;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getNo_of_bags() {
        return no_of_bags;
    }

    public void setNo_of_bags(String no_of_bags) {
        this.no_of_bags = no_of_bags;
    }

    public String getWeight_per_bag() {
        return weight_per_bag;
    }

    public void setWeight_per_bag(String weight_per_bag) {
        this.weight_per_bag = weight_per_bag;
    }

    public String getStockDate() {
        return stockDate;
    }

    public void setStockDate(String stockDate) {
        this.stockDate = stockDate;
    }

    public String getStockTime() {
        return stockTime;
    }

    public void setStockTime(String stockTime) {
        this.stockTime = stockTime;
    }
}