package com.example.sizingmanagement.Splash;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.sizingmanagement.R;
import com.example.sizingmanagement.databinding.FragmentLogInDashboardBinding;

public class LogInDashboard extends Fragment {

    FragmentLogInDashboardBinding binding;

    public LogInDashboard() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentLogInDashboardBinding.inflate(getLayoutInflater());


        // client logIn
        binding.clientLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getContext(), "Coming Soon", Toast.LENGTH_SHORT).show();
            }
        });

        // sizing logIn
        binding.SizingLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FragmentManager manager = getChildFragmentManager();
                FragmentTransaction transaction = manager.beginTransaction();

                transaction.replace(R.id.frag, new LogInFragment());
                transaction.commit();
            }
        });

        return binding.getRoot();
    }
}