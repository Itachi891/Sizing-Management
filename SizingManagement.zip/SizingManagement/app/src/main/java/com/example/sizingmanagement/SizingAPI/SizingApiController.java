package com.example.sizingmanagement.SizingAPI;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class SizingApiController {

    private static SizingApiController controller;
    private static Retrofit retrofit;

    public SizingApiController() {

        //    private final String URL = "http://192.168.43.221:3002";    // mobile

        String URL = "http://192.168.19.106:3002";  // wifi
        retrofit = new Retrofit.Builder()
                .baseUrl(URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }

    public static synchronized SizingApiController getInstance() {

        if (retrofit == null)
            controller = new SizingApiController();

        return controller;
    }

    public SizingApiSet getApi() {

        return retrofit.create(SizingApiSet.class);
    }
}
