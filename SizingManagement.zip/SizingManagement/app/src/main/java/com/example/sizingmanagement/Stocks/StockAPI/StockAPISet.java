package com.example.sizingmanagement.Stocks.StockAPI;

import com.example.sizingmanagement.Stocks.StockModel;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface StockAPISet {

    @POST("/insertStock")
    Call<Void> insertStock(
            @Body StockModel model

//            @Field("jwt") String jwt,
//            @Field("clientCode") String clientCode,
//            @Field("DoNo") String DoNo,
//            @Field("count") String count,
//            @Field("No_of_Bags") String No_of_Bags,
//            @Field("weightPerBag") String weightPerBag,
//            @Field("finalDate") String finalDate,
//            @Field("finalTime") String finalTime,
//            @Field("HSNCode") String HSNCode
    );

    @FormUrlEncoded
    @POST("/displayStock")
    Call<ArrayList<StockModel>> displayStock(

            @Field("clientCode") String clientCode,
            @Field("HSNCode") String HSNCode,
            @Field("userName") String userName,
            @Field("jwt") String jwt
    );
}
