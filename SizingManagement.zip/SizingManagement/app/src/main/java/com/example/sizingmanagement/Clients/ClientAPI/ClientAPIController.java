package com.example.sizingmanagement.Clients.ClientAPI;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ClientAPIController {

    private final String URL = "http://192.168.19.106:3002";

    private static ClientAPIController controller;

    public static Retrofit retrofit;

    public ClientAPIController() {

        retrofit = new Retrofit.Builder().baseUrl(URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }

    public static synchronized ClientAPIController getInstance() {

        if(controller == null) {

            controller = new ClientAPIController();
        }

        return controller;
    }

    public ClientAPISet getAPI() {

        return retrofit.create(ClientAPISet.class);
    }
}
