package com.example.sizingmanagement.SizingProfile;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sizingmanagement.SizingAPI.SizingApiController;
import com.example.sizingmanagement.databinding.ActivityViewSizingProfileBinding;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ViewSizingProfile extends AppCompatActivity {

    ActivityViewSizingProfileBinding binding;
    java.lang.String jwt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityViewSizingProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // view sizing profile
        SharedPreferences preferences = getSharedPreferences("jwt_userName", MODE_PRIVATE);
        jwt = preferences.getString("jwt", null);

        Toast.makeText(this, "in viewSizing" + jwt, Toast.LENGTH_SHORT).show();

        if (jwt != null) {

            Call<SizingModel> call = SizingApiController.getInstance().getApi()
                    .viewSizingProfile(jwt);
            // at this point the request is working

            call.enqueue(new Callback<SizingModel>() {
                @Override
                public void onResponse(Call<SizingModel> call, Response<SizingModel> response) {

                    if (response.code() == 500)
                        Toast.makeText(ViewSizingProfile.this, "Server Error Try after sometime", Toast.LENGTH_SHORT).show();
                    else if (response.code() == 404)
                        Toast.makeText(ViewSizingProfile.this, "User not found", Toast.LENGTH_SHORT).show();
                    else {

                        SizingModel user = response.body();

                        Toast.makeText(ViewSizingProfile.this, user.getUserName() + "ïn view sizing", Toast.LENGTH_SHORT).show();
                        // personal details
                        binding.tvUserName.setText(user.getUserName());
                        binding.tvOwnerName.setText(user.getOwnerName());
                        binding.tvSizing.setText(user.getSizingName());
                        binding.tvStateName.setText(user.getState());
                        binding.tvCityName.setText(user.getCity());
                        binding.tvAddress.setText(user.getAddress());

                        // business details
                        binding.tvBankName.setText(user.getBankName());
                        binding.tvAccountNumber.setText(user.getAccountNumber());
                        binding.tvIFSC.setText(user.getIFSC());
                        binding.tvPan.setText(user.getPAN());
                        binding.tvGSTIN.setText(user.getGSTIN());
                    }
                }

                @Override
                public void onFailure(Call<SizingModel> call, Throwable t) {

                    Toast.makeText(ViewSizingProfile.this, t.getMessage() + " in failure", Toast.LENGTH_SHORT).show();
                }
            });

        } else
            Toast.makeText(this, "Something went wrong, Log In again then try", Toast.LENGTH_SHORT).show();
    }
}