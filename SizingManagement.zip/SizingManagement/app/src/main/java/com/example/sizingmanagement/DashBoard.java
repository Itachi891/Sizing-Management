package com.example.sizingmanagement;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sizingmanagement.Clients.CreateClient;
import com.example.sizingmanagement.Clients.DisplayClients.DisplayClients;
import com.example.sizingmanagement.SizingProfile.ProfileDashBoard;
import com.example.sizingmanagement.Stocks.StockDashBoard;
import com.example.sizingmanagement.databinding.ActivityDashBoardBinding;

public class DashBoard extends AppCompatActivity {

    ActivityDashBoardBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDashBoardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // sizing profile
        binding.sizingProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(DashBoard.this, ProfileDashBoard.class));
            }
        });

        // create client
        binding.createClient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(DashBoard.this, CreateClient.class));
            }
        });

        // display client
        binding.displayClient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(DashBoard.this, DisplayClients.class));
            }
        });

        // stocks
        binding.stocks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(DashBoard.this, StockDashBoard.class));
            }
        });
    }
}