package com.example.sizingmanagement.Stocks;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sizingmanagement.R;

import java.util.ArrayList;

public class AdapterDisplayStock extends RecyclerView.Adapter<AdapterDisplayStock.StockViewHolder>{

    Context context;
    ArrayList<StockModel> list;

    public AdapterDisplayStock(Context context, ArrayList<StockModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public StockViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.single_row_display_clients, parent);

        return new StockViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StockViewHolder holder, int position) {

        holder.date.setText(list.get(position).getStockDate());
        holder.HSN.setText(list.get(position).getHSNCode());
        holder.clientName.setText(list.get(position).getClientName());
        holder.DoNumber.setText(list.get(position).getDoNo());
        holder.count.setText(list.get(position).getCount());
        holder.bags.setText(list.get(position).getNo_of_bags());
        holder.weighPer.setText(list.get(position).getWeight_per_bag());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class StockViewHolder extends RecyclerView.ViewHolder {

        TextView date;
        TextView HSN;
        TextView clientName;
        TextView count;
        TextView bags;
        TextView weighPer;
        TextView DoNumber;
        public  StockViewHolder(@NonNull View itemView) {
            super(itemView);

            date = itemView.findViewById(R.id.tv_date);
            HSN = itemView.findViewById(R.id.tv_HSN);
            clientName = itemView.findViewById(R.id.tv_clientName);
            count = itemView.findViewById(R.id.tv_count);
            bags = itemView.findViewById(R.id.tv_bags);
            weighPer = itemView.findViewById(R.id.tv_weightPerBag);
            DoNumber = itemView.findViewById(R.id.tv_DONo);
        }
    }
}
