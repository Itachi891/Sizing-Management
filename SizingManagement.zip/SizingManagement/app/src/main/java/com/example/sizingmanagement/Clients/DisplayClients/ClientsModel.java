package com.example.sizingmanagement.Clients.DisplayClients;

public class ClientsModel {

    public ClientsModel() {
    }

    String clientCode, ownerName, password, contact1, contact2, HSN, state, city, address;

    public ClientsModel(String clientCode, String ownerName, String password, String contact1, String contact2, String HSN, String state, String city, String address) {
        this.clientCode = clientCode;
        this.ownerName = ownerName;
        this.password = password;
        this.contact1 = contact1;
        this.contact2 = contact2;
        this.HSN = HSN;
        this.state = state;
        this.city = city;
        this.address = address;
    }

    public String getClientCode() {
        return clientCode;
    }

    public void setClientCode(String clientCode) {
        this.clientCode = clientCode;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getContact1() {
        return contact1;
    }

    public void setContact1(String contact1) {
        this.contact1 = contact1;
    }

    public String getContact2() {
        return contact2;
    }

    public void setContact2(String contact2) {
        this.contact2 = contact2;
    }

    public String getHSN() {
        return HSN;
    }

    public void setHSN(String HSN) {
        this.HSN = HSN;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
