package com.example.sizingmanagement.Universal;

import java.util.ArrayList;

public class CheckFieldIsEmpty {

    public boolean checkIsEmpty(ArrayList<String> list) {

        for (String element: list) {

            if (element.isEmpty()) {

                return true;
            }
        }
        return false;
    }
}
