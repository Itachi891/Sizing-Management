package com.example.sizingmanagement.Clients;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sizingmanagement.Clients.ClientAPI.ClientAPIController;
import com.example.sizingmanagement.Clients.DisplayClients.ClientsModel;
import com.example.sizingmanagement.Universal.CheckFieldIsEmpty;
import com.example.sizingmanagement.databinding.ActivityCreateClientBinding;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CreateClient extends AppCompatActivity {

    ActivityCreateClientBinding binding;
    String ownerName, clientCode, password, contact1, contact2, state, city, address, jwt, HSN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateClientBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ownerName = binding.etClientName.getText().toString().toLowerCase();
                clientCode = binding.etClientCode.getText().toString().toLowerCase();
                password = binding.etClientPassword.getText().toString().toLowerCase();
                contact1 = binding.etClientContact1.getText().toString().toLowerCase();
                contact2 = binding.etClientContact2.getText().toString().toLowerCase();
                state = binding.etClientState.getText().toString().toLowerCase();
                city = binding.etClientCity.getText().toString().toLowerCase();
                address = binding.etClientAddress.getText().toString().toLowerCase();
                HSN = binding.etHSN.getText().toString().toLowerCase();

                ArrayList<String> list = new ArrayList<>();
                list.add(ownerName);
                list.add(clientCode);
                list.add(password);
                list.add(contact1);
                list.add(contact2);
                list.add(state);
                list.add(city);
                list.add(address);
                list.add(HSN);

                CheckFieldIsEmpty obj = new CheckFieldIsEmpty();
                boolean flag = obj.checkIsEmpty(list);

                if (flag)
                    Toast.makeText(CreateClient.this, "All Fields are Mandatory", Toast.LENGTH_SHORT).show();
                else {

                    SharedPreferences preferences = getSharedPreferences("jwt_userName", MODE_PRIVATE);
                    jwt = preferences.getString("jwt",
                            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY0NTI5YzFhZWE1MDZiYjkwZTMxMzgwZiIsImlhdCI6MTY4MzgwMDMxMH0.OUDKsS54r1Q-vs1R8bN1QPJaA8Mt-yHCEKypz2k9wy4");

                        Toast.makeText(CreateClient.this, "In create Client" + jwt , Toast.LENGTH_SHORT).show();

                    if (jwt != null)
                        Toast.makeText(CreateClient.this, "Something went wrong, Log In again then try", Toast.LENGTH_SHORT).show();
                    else {

                        createClient();
                    }
                }
            }
        });
    }

    private void createClient() {

        ClientsModel model = new ClientsModel(clientCode, ownerName, password, contact1, contact2, HSN, state, city, address);

        Call<Void> call = ClientAPIController.getInstance()
                .getAPI()
                .createClient(model);

        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {

                if (response.code() == 500)
                    Toast.makeText(CreateClient.this, "Server Error, Try after sometime", Toast.LENGTH_SHORT).show();

                else if (response.code() == 403)
                    Toast.makeText(CreateClient.this, "Client Code already present", Toast.LENGTH_SHORT).show();

                else if (response.code() == 201) {

                    Toast.makeText(CreateClient.this, "Client Created Successfully", Toast.LENGTH_SHORT).show();

                    binding.etClientName.setText("");
                    binding.etClientCode.setText("");
                    binding.etClientPassword.setText("");
                    binding.etClientContact1.setText("");
                    binding.etClientContact2.setText("");
                    binding.etClientState.setText("");
                    binding.etClientCity.setText("");
                    binding.etClientAddress.setText("");
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {

                Toast.makeText(CreateClient.this, t.getMessage() + "in failure", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void emptyText() {

        binding.etClientCode.setText("");
        binding.etClientName.setText("");
        binding.etClientPassword.setText("");
        binding.etClientContact1.setText("");
        binding.etClientContact2.setText("");
        binding.etClientState.setText("");
        binding.etClientCity.setText("");
        binding.etClientAddress.setText("");
    }
}