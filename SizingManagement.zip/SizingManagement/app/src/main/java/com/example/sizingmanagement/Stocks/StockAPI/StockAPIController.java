package com.example.sizingmanagement.Stocks.StockAPI;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class StockAPIController {

    private static Retrofit retrofit;
    private static StockAPIController controller;

    public StockAPIController() {

        // wifi
        String URL = "http://192.168.19.106:3002";
        retrofit = new Retrofit.Builder()
                .baseUrl(URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }

    public static synchronized StockAPIController getInstance() {


        if (retrofit == null)
            controller = new StockAPIController();

        return controller;
    }

    public StockAPISet getAPI() {

        return retrofit.create(StockAPISet.class);
    }

}
