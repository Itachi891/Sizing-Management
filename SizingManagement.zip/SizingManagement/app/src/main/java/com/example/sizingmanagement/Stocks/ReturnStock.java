package com.example.sizingmanagement.Stocks;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.sizingmanagement.R;

public class ReturnStock extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_return_stock);
    }
}