package com.example.sizingmanagement.Stocks;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.sizingmanagement.Stocks.StockAPI.StockAPIController;
import com.example.sizingmanagement.databinding.ActivityDisplayStockBinding;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DisplayStock extends AppCompatActivity {

    ActivityDisplayStockBinding binding;
    ArrayList<StockModel> list;
    String clientCode, HSNCode, userName, jwt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDisplayStockBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.displayRecyclerView.setLayoutManager(new LinearLayoutManager(DisplayStock.this));

        binding.btnDisplay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                clientCode = binding.displayClientCode.getText().toString();
                HSNCode = binding.displayHSNCode.getText().toString();

                if (clientCode.isEmpty())
                    Toast.makeText(DisplayStock.this, "Enter Client Code", Toast.LENGTH_SHORT).show();

                else if (HSNCode.isEmpty())
                    Toast.makeText(DisplayStock.this, "Enter Client Code", Toast.LENGTH_SHORT).show();

                else {

                    SharedPreferences preferences = getSharedPreferences("jwt_userName", MODE_PRIVATE);
                    userName = preferences.getString("userName",null);
                    jwt = preferences.getString("jwt", null);

                    if (userName != null && jwt != null)
                        Toast.makeText(DisplayStock.this, "Something went wrong, Log In again then try", Toast.LENGTH_SHORT).show();
                    else {

                    display();

                    AdapterDisplayStock adapter = new AdapterDisplayStock(DisplayStock.this, list);
                    binding.displayRecyclerView.setAdapter(adapter);
                    }
                }

            }
        });

    }

    // method to fetch the data from database
    private void display() {

        Call<ArrayList<StockModel>> call = StockAPIController.getInstance().getAPI()
                .displayStock(clientCode, HSNCode, userName, jwt);

        call.enqueue(new Callback<ArrayList<StockModel>>() {
            @Override
            public void onResponse(Call<ArrayList<StockModel>> call, Response<ArrayList<StockModel>> response) {

                if (response.code() == 500)
                    Toast.makeText(DisplayStock.this, "Server Error, Try after Sometime", Toast.LENGTH_SHORT).show();

                else if (response.code() == 404)
                    Toast.makeText(DisplayStock.this, "Invalid Input", Toast.LENGTH_SHORT).show();

                else if (response.code() == 200)
                    list = response.body();
            }

            @Override
            public void onFailure(Call<ArrayList<StockModel>> call, Throwable t) {

                Toast.makeText(DisplayStock.this, t.getMessage() + "in failure", Toast.LENGTH_SHORT).show();
            }
        });
    }
}