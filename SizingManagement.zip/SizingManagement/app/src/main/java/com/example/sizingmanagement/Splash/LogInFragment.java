package com.example.sizingmanagement.Splash;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.sizingmanagement.DashBoard;
import com.example.sizingmanagement.SizingAPI.SizingApiController;
import com.example.sizingmanagement.SizingProfile.SizingModel;
import com.example.sizingmanagement.Universal.CheckInternetAccess;
import com.example.sizingmanagement.databinding.FragmentLogInBinding;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LogInFragment extends Fragment {

    public LogInFragment() {
        // Required empty public constructor
    }

    FragmentLogInBinding binding;
    String userName, password;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentLogInBinding.inflate(getLayoutInflater(), container, false);


        binding.login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                userName = binding.etUserName.getText().toString().toLowerCase().trim();
                password = binding.etPassword.getText().toString().toLowerCase().trim();

                if (userName.isEmpty())
                    Toast.makeText(getContext(), "All fields are mandatory", Toast.LENGTH_SHORT).show();
                else if (password.isEmpty())
                    Toast.makeText(getContext(), "All fields are mandatory", Toast.LENGTH_SHORT).show();
                else {

                    // check internet access
                    boolean internet = CheckInternetAccess.getInternetAccess(getContext());
                    if (!internet)
                        Toast.makeText(getContext(), "Check Your Internet Connection", Toast.LENGTH_SHORT).show();
                    else
                        logIn();
                }
            }
        });
        return binding.getRoot();
    }

    private void logIn() {

        userName = userName.substring(0, 1).toUpperCase() + userName.substring(1);
        SizingModel model = new SizingModel(userName, password);

        Call<String> call = SizingApiController.getInstance().getApi().logIn(model);

        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {

                if (response.code() == 404)
                    Toast.makeText(getContext(), "User not found", Toast.LENGTH_SHORT).show();

                else if (response.code() == 500)
                    Toast.makeText(getContext(), "Server Error, try after some time", Toast.LENGTH_SHORT).show();

                else if (response.code() == 403)
                    Toast.makeText(getContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();

                else {

                    String res = response.body();
                    Toast.makeText(getContext(), "in login" + res, Toast.LENGTH_SHORT).show();

                    SharedPreferences preferences = getActivity().getSharedPreferences("jwt_userName", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();

                    editor.putString("jwt", res);
                    editor.putBoolean("flag", true);
                    editor.apply();

                    progressDialog();

                    startActivity(new Intent(getContext(), DashBoard.class));
                    getActivity().finish();
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {

                Toast.makeText(getContext(), t.getMessage() + "in failure", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void progressDialog() {

    }
}
