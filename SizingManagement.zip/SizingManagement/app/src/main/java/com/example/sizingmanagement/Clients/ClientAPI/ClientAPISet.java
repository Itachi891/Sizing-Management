package com.example.sizingmanagement.Clients.ClientAPI;

import com.example.sizingmanagement.Clients.DisplayClients.ClientsModel;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ClientAPISet {

    // displayClients
    @FormUrlEncoded
    @POST("/displayClients")
    Call<ArrayList<ClientsModel>> displayClient(

            @Field("clientCode") String clientCode,
            @Field("jwt") String jwt
    );

    @POST("/createClient")
    Call<Void> createClient(@Body ClientsModel model);
}
