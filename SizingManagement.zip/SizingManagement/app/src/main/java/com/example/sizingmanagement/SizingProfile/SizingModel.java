package com.example.sizingmanagement.SizingProfile;

public class SizingModel {

    public SizingModel() {
    }


//    String userName, token, ownerName, password, sizingName, state, city, address, bankName, accountNumber, IFSC, PAN, GSTIN;

    String ownerName, sizingName, password, contact1, contact2, state, city, address, bankName, IFSC, accountNumber, PAN, GSTIN, jwt, userName;

    public SizingModel(String ownerName, String password, String contact1, String contact2, String address, String bankName, String IFSC, String accountNumber, String PAN, String GSTIN, String jwt) {
        this.ownerName = ownerName;
        this.password = password;
        this.contact1 = contact1;
        this.contact2 = contact2;
        this.address = address;
        this.bankName = bankName;
        this.IFSC = IFSC;
        this.accountNumber = accountNumber;
        this.PAN = PAN;
        this.GSTIN = GSTIN;
        this.jwt = jwt;
    }

    public SizingModel(String ownerName, String sizingName, String password, String contact1, String contact2, String state, String city, String address, String bankName, String IFSC, String accountNumber, String PAN, String GSTIN, String jwt) {
        this.ownerName = ownerName;
        this.sizingName = sizingName;
        this.password = password;
        this.contact1 = contact1;
        this.contact2 = contact2;
        this.state = state;
        this.city = city;
        this.address = address;
        this.bankName = bankName;
        this.IFSC = IFSC;
        this.accountNumber = accountNumber;
        this.PAN = PAN;
        this.GSTIN = GSTIN;
        this.jwt = jwt;
    }

    public String getContact1() {
        return contact1;
    }

    public void setContact1(String contact1) {
        this.contact1 = contact1;
    }

    public String getContact2() {
        return contact2;
    }

    public void setContact2(String contact2) {
        this.contact2 = contact2;
    }

    public String getJwt() {
        return jwt;
    }

    public void setJwt(String token) {
        this.jwt = token;
    }


    public SizingModel(java.lang.String userName, java.lang.String password) {
        this.userName = userName;
        this.password = password;
    }
    public java.lang.String getUserName() {
        return userName;
    }

    public void setUserName(java.lang.String userName) {
        this.userName = userName;
    }

    public java.lang.String getPassword() {
        return password;
    }

    public void setPassword(java.lang.String password) {
        this.password = password;
    }

    public java.lang.String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(java.lang.String ownerName) {
        this.ownerName = ownerName;
    }

    public java.lang.String getSizingName() {
        return sizingName;
    }

    public void setSizingName(java.lang.String sizingName) {
        this.sizingName = sizingName;
    }

    public java.lang.String getState() {
        return state;
    }

    public void setState(java.lang.String state) {
        this.state = state;
    }

    public java.lang.String getCity() {
        return city;
    }

    public void setCity(java.lang.String city) {
        this.city = city;
    }

    public java.lang.String getAddress() {
        return address;
    }

    public void setAddress(java.lang.String address) {
        this.address = address;
    }

    public java.lang.String getBankName() {
        return bankName;
    }

    public void setBankName(java.lang.String bankName) {
        this.bankName = bankName;
    }

    public java.lang.String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(java.lang.String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public java.lang.String getIFSC() {
        return IFSC;
    }

    public void setIFSC(java.lang.String IFSC) {
        this.IFSC = IFSC;
    }

    public java.lang.String getPAN() {
        return PAN;
    }

    public void setPAN(java.lang.String PAN) {
        this.PAN = PAN;
    }

    public java.lang.String getGSTIN() {
        return GSTIN;
    }

    public void setGSTIN(java.lang.String GSTIN) {
        this.GSTIN = GSTIN;
    }
}
