package com.example.sizingmanagement.SizingProfile;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sizingmanagement.SizingAPI.SizingApiController;
import com.example.sizingmanagement.Universal.CheckFieldIsEmpty;
import com.example.sizingmanagement.databinding.ActivityEditSizingProfileBinding;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditSizingProfile extends AppCompatActivity {

    ActivityEditSizingProfileBinding binding;
    String ownerName, sizingName, password, contact1, contact2, state, city, address, bankName, accountNumber, IFSC, jwt, GSTIN, PAN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditSizingProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ownerName = binding.etOwnerName.getText().toString();
                sizingName = binding.etSizing.getText().toString();
                password = binding.etPass.getText().toString();
                contact1 = binding.etContact1.getText().toString();
                contact2 = binding.etContact2.getText().toString();
                state = binding.etState.getText().toString();
                city = binding.etCity.getText().toString();
                address = binding.etAddress.getText().toString();
                bankName = binding.etBankName.getText().toString();
                accountNumber = binding.etBankName.getText().toString();
                IFSC = binding.etIFSC.getText().toString();
                GSTIN = binding.etIFSC.getText().toString();
                PAN = binding.etIFSC.getText().toString();

                ArrayList<String> list = new ArrayList<>();

                list.add(ownerName);
                list.add(sizingName);
                list.add(password);
                list.add(contact1);
                list.add(contact2);
                list.add(address);
                list.add(bankName);
                list.add(accountNumber);
                list.add(IFSC);
                list.add(GSTIN);
                list.add(PAN);

                CheckFieldIsEmpty obj = new CheckFieldIsEmpty();

                if (obj.checkIsEmpty(list)) {
                    Toast.makeText(EditSizingProfile.this, "All Fields are mandatory", Toast.LENGTH_SHORT).show();

                } else {

                    SharedPreferences preferences = getSharedPreferences("jwt_userName", MODE_PRIVATE);
                    jwt = preferences.getString("jwt","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY0NTI5YzFhZWE1MDZiYjkwZTMxMzgwZiIsImlhdCI6MTY4MzgwMDg1MX0.ybqAR7h6itqbBIzFXGkZFxovEiWKOlhMJF9aRRO5F7E");

                    Toast.makeText(EditSizingProfile.this, "in editProfile" + jwt, Toast.LENGTH_SHORT).show();
                    if (jwt != null) {
                        Toast.makeText(EditSizingProfile.this, "in if " + jwt, Toast.LENGTH_SHORT).show();
                        updateData();
                    } else
                        Toast.makeText(EditSizingProfile.this, "Something went wrong, Log In again then try", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void updateData() {

        SizingModel model = new SizingModel(ownerName, password, contact1, contact2, address, bankName, IFSC, accountNumber, PAN, GSTIN, jwt);

        Call<Void> call = SizingApiController.getInstance().getApi().editSizingProfile(model);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {

                if (response.code() == 500)
                    Toast.makeText(EditSizingProfile.this, "Server Error, Try after some time", Toast.LENGTH_SHORT).show();

                else if (response.code() == 404)
                    Toast.makeText(EditSizingProfile.this, "user not found", Toast.LENGTH_SHORT).show();

                else {
                    Toast.makeText(EditSizingProfile.this, "Profile updated successfully", Toast.LENGTH_SHORT).show();
                    emptyText();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {

                Toast.makeText(EditSizingProfile.this, t.getMessage() + "in failure", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void emptyText() {

        binding.etOwnerName.setText("");
        binding.etSizing.setText("");
        binding.etContact1.setText("");
        binding.etContact2.setText("");
        binding.etState.setText("");
        binding.etCity.setText("");
        binding.etAddress.setText("");
        binding.etBankName.setText("");
        binding.etBankName.setText("");
        binding.etIFSC.setText("");
        binding.etAccountNumber.setText("");
        binding.etPAN.setText("");
        binding.etGSTIN.setText("");
    }
}