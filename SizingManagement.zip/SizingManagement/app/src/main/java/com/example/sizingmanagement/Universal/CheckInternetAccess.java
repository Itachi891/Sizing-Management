package com.example.sizingmanagement.Universal;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class CheckInternetAccess {


    public static boolean getInternetAccess(Context context) {

        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = manager.getActiveNetworkInfo();

        if (networkInfo == null)
            return false;
        else {

            if (networkInfo.getType() == ConnectivityManager.TYPE_WIFI)
                return true;
            else if (networkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
                return true;
            }
        }
        return false;
    }
}
