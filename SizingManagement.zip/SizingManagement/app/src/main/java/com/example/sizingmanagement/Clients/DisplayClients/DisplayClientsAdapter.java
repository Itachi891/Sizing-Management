package com.example.sizingmanagement.Clients.DisplayClients;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sizingmanagement.R;

import java.util.ArrayList;

public class DisplayClientsAdapter extends RecyclerView.Adapter<DisplayClientsAdapter.ViewHolder> {

    Context context;
    ArrayList<ClientsModel> list;

    public DisplayClientsAdapter(Context context, ArrayList<ClientsModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.single_row_display_clients, parent);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.name.setText(list.get(position).getOwnerName());
        holder.code.setText(list.get(position).getClientCode());
        holder.contact1.setText(list.get(position).getContact1());
        holder.contact2.setText(list.get(position).getContact2());
        holder.HSN.setText(list.get(position).getHSN());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView name;
        TextView code;
        TextView contact1;
        TextView contact2;
        TextView HSN;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.clientsName);
            code = itemView.findViewById(R.id.clientsCode);
            contact1 = itemView.findViewById(R.id.clientsContact1);
            contact2 = itemView.findViewById(R.id.clientsContact2);
            HSN = itemView.findViewById(R.id.clientsHSN);
        }
    }
}
