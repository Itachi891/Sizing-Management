package com.example.sizingmanagement.SizingProfile;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sizingmanagement.databinding.ActivityProfileDashBoardBinding;

public class ProfileDashBoard extends AppCompatActivity {

    ActivityProfileDashBoardBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProfileDashBoardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // view Sizing profile
        binding.viewSizingProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(ProfileDashBoard.this, ViewSizingProfile.class));
            }
        });

        // edit sizing profile
        binding.editSizingProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ProfileDashBoard.this, EditSizingProfile.class));
            }
        });

    }
}